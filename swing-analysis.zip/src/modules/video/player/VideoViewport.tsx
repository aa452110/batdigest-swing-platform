import React, { forwardRef, useImperativeHandle, useRef } from 'react';
import type { AspectRatio } from '../../../types/media';

export interface VideoViewportRef {
  video: HTMLVideoElement | null;
  container: HTMLDivElement | null;
  play: () => Promise<void>;
  pause: () => void;
  seekTo: (time: number) => void;
}

interface VideoViewportProps {
  src: string | null;
  aspectRatio?: AspectRatio;
  onLoadedMetadata?: (e: React.SyntheticEvent<HTMLVideoElement>) => void;
  onTimeUpdate?: (e: React.SyntheticEvent<HTMLVideoElement>) => void;
  onPlay?: () => void;
  onPause?: () => void;
  onEnded?: () => void;
  onError?: (error: string) => void;
  className?: string;
}

const VideoViewport = forwardRef<VideoViewportRef, VideoViewportProps>(
  (
    {
      src,
      aspectRatio = '16:9',
      onLoadedMetadata,
      onTimeUpdate,
      onPlay,
      onPause,
      onEnded,
      onError,
      className = '',
    },
    ref
  ) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    useImperativeHandle(ref, () => ({
      video: videoRef.current,
      container: containerRef.current,
      play: async () => {
        if (videoRef.current) {
          try {
            await videoRef.current.play();
            onPlay?.();
          } catch (error) {
            onError?.(error instanceof Error ? error.message : 'Failed to play video');
          }
        }
      },
      pause: () => {
        if (videoRef.current) {
          videoRef.current.pause();
          onPause?.();
        }
      },
      seekTo: (time: number) => {
        if (videoRef.current) {
          videoRef.current.currentTime = Math.max(0, Math.min(time, videoRef.current.duration));
        }
      },
    }));

    const getAspectRatioClass = () => {
      switch (aspectRatio) {
        case '16:9':
          return 'aspect-video';
        case '4:3':
          return 'aspect-4/3';
        case 'free':
          return '';
        default:
          return 'aspect-video';
      }
    };

    if (!src) {
      return (
        <div className="flex items-center justify-center h-64 bg-gray-800 rounded-lg">
          <p className="text-gray-400">No video loaded</p>
        </div>
      );
    }

    return (
      <div
        ref={containerRef}
        className={`relative bg-black rounded-lg overflow-hidden ${className}`}
      >
        <div className={`relative ${getAspectRatioClass()} max-w-full mx-auto`}>
          <video
            ref={videoRef}
            src={src}
            className="w-full h-full object-contain"
            playsInline
            preload="metadata"
            crossOrigin="anonymous"
            onLoadedMetadata={onLoadedMetadata}
            onTimeUpdate={onTimeUpdate}
            onPlay={onPlay}
            onPause={onPause}
            onEnded={onEnded}
            onError={(e) => {
              const video = e.currentTarget;
              const error = video.error;
              if (error) {
                onError?.(`Video error: ${error.message}`);
              }
            }}
          />
        </div>
      </div>
    );
  }
);

VideoViewport.displayName = 'VideoViewport';

export default VideoViewport;