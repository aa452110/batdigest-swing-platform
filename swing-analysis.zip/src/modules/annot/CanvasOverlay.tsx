import React, { useRef, useEffect, useCallback } from 'react';
import type { Annotation, AnnotationStyle, Point } from './types';

interface CanvasOverlayProps {
  width: number;
  height: number;
  annotations: Annotation[];
  tempAnnotation?: Partial<Annotation>;
  selectedId?: string | null;
  onCanvasReady?: (canvas: HTMLCanvasElement) => void;
}

const CanvasOverlay: React.FC<CanvasOverlayProps> = ({
  width,
  height,
  annotations,
  tempAnnotation,
  selectedId,
  onCanvasReady,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Drawing utilities
  const drawLine = useCallback(
    (ctx: CanvasRenderingContext2D, points: Point[], style: AnnotationStyle) => {
      if (points.length < 2) return;

      ctx.strokeStyle = style.color;
      ctx.lineWidth = style.thickness;
      ctx.globalAlpha = style.opacity || 1;

      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      ctx.lineTo(points[1].x, points[1].y);
      ctx.stroke();
    },
    []
  );

  const drawArrow = useCallback(
    (ctx: CanvasRenderingContext2D, points: Point[], style: AnnotationStyle) => {
      if (points.length < 2) return;

      const [start, end] = points;
      const headLength = 15;
      const angle = Math.atan2(end.y - start.y, end.x - start.x);

      ctx.strokeStyle = style.color;
      ctx.lineWidth = style.thickness;
      ctx.globalAlpha = style.opacity || 1;

      // Draw line
      ctx.beginPath();
      ctx.moveTo(start.x, start.y);
      ctx.lineTo(end.x, end.y);
      ctx.stroke();

      // Draw arrowhead
      ctx.beginPath();
      ctx.moveTo(end.x, end.y);
      ctx.lineTo(
        end.x - headLength * Math.cos(angle - Math.PI / 6),
        end.y - headLength * Math.sin(angle - Math.PI / 6)
      );
      ctx.moveTo(end.x, end.y);
      ctx.lineTo(
        end.x - headLength * Math.cos(angle + Math.PI / 6),
        end.y - headLength * Math.sin(angle + Math.PI / 6)
      );
      ctx.stroke();
    },
    []
  );

  const drawBox = useCallback(
    (ctx: CanvasRenderingContext2D, points: Point[], style: AnnotationStyle) => {
      if (points.length < 2) return;

      const [start, end] = points;
      const boxWidth = end.x - start.x;
      const boxHeight = end.y - start.y;

      ctx.strokeStyle = style.color;
      ctx.lineWidth = style.thickness;
      ctx.globalAlpha = style.opacity || 1;

      ctx.strokeRect(start.x, start.y, boxWidth, boxHeight);
    },
    []
  );

  // Main render function
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw each annotation
    annotations.forEach((annotation) => {
      ctx.save();

      // Highlight selected annotation
      if (annotation.id === selectedId) {
        ctx.shadowColor = 'rgba(59, 130, 246, 0.5)';
        ctx.shadowBlur = 10;
      }

      switch (annotation.tool) {
        case 'line':
          drawLine(ctx, annotation.points, annotation.style);
          break;
        case 'arrow':
          drawArrow(ctx, annotation.points, annotation.style);
          break;
        case 'box':
          drawBox(ctx, annotation.points, annotation.style);
          break;
      }

      ctx.restore();
    });

    // Draw temp annotation (while drawing)
    if (tempAnnotation?.points && tempAnnotation.points.length >= 2 && tempAnnotation.style) {
      ctx.save();
      ctx.globalAlpha = 0.7; // Slightly transparent while drawing

      switch (tempAnnotation.tool) {
        case 'line':
          drawLine(ctx, tempAnnotation.points, tempAnnotation.style);
          break;
        case 'arrow':
          drawArrow(ctx, tempAnnotation.points, tempAnnotation.style);
          break;
        case 'box':
          drawBox(ctx, tempAnnotation.points, tempAnnotation.style);
          break;
      }

      ctx.restore();
    }
  }, [annotations, tempAnnotation, selectedId, drawLine, drawArrow, drawBox]);

  // Notify parent when canvas is ready
  useEffect(() => {
    if (canvasRef.current && onCanvasReady) {
      onCanvasReady(canvasRef.current);
    }
  }, [onCanvasReady]);

  // Re-render when props change
  useEffect(() => {
    render();
  }, [render]);

  // Handle resize
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Update internal resolution
    canvas.width = width;
    canvas.height = height;

    // Re-render with new dimensions
    render();
  }, [width, height, render]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none"
      style={{
        width: '100%',
        height: '100%',
      }}
    />
  );
};

export default CanvasOverlay;