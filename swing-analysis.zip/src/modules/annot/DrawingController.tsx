import React, { useState, useCallback, useRef } from 'react';
import type { Point, Annotation, AnnotationStyle, ToolType } from './types';

interface DrawingControllerProps {
  currentTool: ToolType;
  currentStyle: AnnotationStyle;
  currentTime: number;
  isPlaying: boolean;
  canvasWidth: number;
  canvasHeight: number;
  onAnnotationComplete: (annotation: Annotation) => void;
  onAnnotationSelect: (id: string | null) => void;
  annotations: Annotation[];
  children: (props: {
    onMouseDown: (e: React.MouseEvent) => void;
    onMouseMove: (e: React.MouseEvent) => void;
    onMouseUp: (e: React.MouseEvent) => void;
    onMouseLeave: (e: React.MouseEvent) => void;
    tempAnnotation: Partial<Annotation> | undefined;
    isDrawing: boolean;
  }) => React.ReactNode;
}

const DrawingController: React.FC<DrawingControllerProps> = ({
  currentTool,
  currentStyle,
  currentTime,
  isPlaying,
  canvasWidth,
  canvasHeight,
  onAnnotationComplete,
  onAnnotationSelect,
  annotations,
  children,
}) => {
  const [isDrawing, setIsDrawing] = useState(false);
  const [tempPoints, setTempPoints] = useState<Point[]>([]);
  const [drawStartTime, setDrawStartTime] = useState<number>(0);
  const containerRef = useRef<HTMLElement | null>(null);

  const getPoint = useCallback((e: React.MouseEvent, canvasWidth: number, canvasHeight: number): Point => {
    const target = e.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();
    // Convert to canvas pixel coordinates
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvasWidth,
      y: ((e.clientY - rect.top) / rect.height) * canvasHeight,
    };
  }, []);

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      const point = getPoint(e, canvasWidth, canvasHeight);

      if (currentTool === 'select') {
        // Find clicked annotation
        const clicked = annotations.find((ann) => {
          if (ann.points.length < 2) return false;
          const [p1, p2] = ann.points;
          const minX = Math.min(p1.x, p2.x) - 2;
          const maxX = Math.max(p1.x, p2.x) + 2;
          const minY = Math.min(p1.y, p2.y) - 2;
          const maxY = Math.max(p1.y, p2.y) + 2;
          return point.x >= minX && point.x <= maxX && point.y >= minY && point.y <= maxY;
        });

        onAnnotationSelect(clicked?.id || null);
      } else {
        // Start drawing
        setIsDrawing(true);
        setDrawStartTime(currentTime);
        setTempPoints([point, point]);
      }
    },
    [currentTool, currentTime, annotations, getPoint, onAnnotationSelect, canvasWidth, canvasHeight]
  );

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!isDrawing) return;
      const point = getPoint(e, canvasWidth, canvasHeight);
      setTempPoints((prev) => [prev[0], point]);
    },
    [isDrawing, getPoint, canvasWidth, canvasHeight]
  );

  const handleMouseUp = useCallback(() => {
    if (!isDrawing || tempPoints.length < 2) {
      setIsDrawing(false);
      setTempPoints([]);
      return;
    }

    // Create annotation
    const annotation: Annotation = {
      id: `ann-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      tool: currentTool as Exclude<ToolType, 'select'>,
      points: [...tempPoints],
      style: { ...currentStyle },
      tStart: drawStartTime,
      tEnd: isPlaying ? currentTime : drawStartTime + 5, // Default 5 second duration if paused
    };

    onAnnotationComplete(annotation);

    setIsDrawing(false);
    setTempPoints([]);
  }, [isDrawing, tempPoints, currentTool, currentStyle, drawStartTime, currentTime, isPlaying, onAnnotationComplete]);

  const handleMouseLeave = useCallback(() => {
    if (isDrawing) {
      setIsDrawing(false);
      setTempPoints([]);
    }
  }, [isDrawing]);

  const tempAnnotation = isDrawing && tempPoints.length >= 2
    ? {
        tool: currentTool as Exclude<ToolType, 'select'>,
        points: tempPoints,
        style: currentStyle,
      }
    : undefined;

  return (
    <>
      {children({
        onMouseDown: handleMouseDown,
        onMouseMove: handleMouseMove,
        onMouseUp: handleMouseUp,
        onMouseLeave: handleMouseLeave,
        tempAnnotation,
        isDrawing,
      })}
    </>
  );
};

export default DrawingController;