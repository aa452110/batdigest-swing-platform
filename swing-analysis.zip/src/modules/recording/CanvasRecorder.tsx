import React, { useRef, useState, useCallback, useEffect } from 'react';

const CanvasRecorder: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  
  const [isCapturing, setIsCapturing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordedSegments, setRecordedSegments] = useState<any[]>([]);

  // Function to capture the entire video container using html2canvas approach
  const captureVideoFrame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Find the main video container based on view mode
    const singleVideoContainer = document.querySelector('.aspect-\\[16\\/9\\].bg-black.rounded-lg.relative:not([data-video-container])');
    const splitVideoContainer = document.querySelector('[data-video-container="true"].aspect-\\[16\\/9\\]');
    
    const containerToCapture = splitVideoContainer || singleVideoContainer;
    
    if (!containerToCapture) {
      console.warn('Video container not found');
      return;
    }

    // Get the container's bounding rect
    const rect = containerToCapture.getBoundingClientRect();
    
    // Scale factors to fit the container into our canvas
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const scale = Math.min(scaleX, scaleY);
    
    // Center the content
    const offsetX = (canvas.width - rect.width * scale) / 2;
    const offsetY = (canvas.height - rect.height * scale) / 2;
    
    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.scale(scale, scale);
    
    // Draw videos
    const videos = containerToCapture.querySelectorAll('video');
    videos.forEach((video) => {
      if (video.readyState < 2) return;
      
      const videoRect = video.getBoundingClientRect();
      const x = videoRect.left - rect.left;
      const y = videoRect.top - rect.top;
      
      // Get the computed transform to capture zoom
      const computedStyle = window.getComputedStyle(video);
      const transform = computedStyle.transform;
      
      ctx.save();
      
      // Apply the video's transform (includes zoom and pan)
      if (transform && transform !== 'none') {
        const matrix = new DOMMatrix(transform);
        ctx.transform(
          matrix.a, matrix.b, matrix.c,
          matrix.d, x + videoRect.width/2, y + videoRect.height/2
        );
        ctx.drawImage(video, -videoRect.width/2, -videoRect.height/2, videoRect.width, videoRect.height);
      } else {
        ctx.drawImage(video, x, y, videoRect.width, videoRect.height);
      }
      
      ctx.restore();
    });
    
    // Draw all canvas elements (annotations) on top
    const canvases = containerToCapture.querySelectorAll('canvas:not(#recording-canvas)');
    canvases.forEach((annotationCanvas: HTMLCanvasElement) => {
      const canvasRect = annotationCanvas.getBoundingClientRect();
      const x = canvasRect.left - rect.left;
      const y = canvasRect.top - rect.top;
      
      ctx.drawImage(annotationCanvas, x, y, canvasRect.width, canvasRect.height);
    });
    
    ctx.restore();
  }, []);

  // Animation loop for continuous capture
  const startCaptureLoop = useCallback(() => {
    const loop = () => {
      captureVideoFrame();
      animationFrameRef.current = requestAnimationFrame(loop);
    };
    loop();
  }, [captureVideoFrame]);

  const stopCaptureLoop = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
  }, []);

  const startRecording = useCallback(async () => {
    try {
      const canvas = canvasRef.current;
      if (!canvas) {
        throw new Error('Canvas not initialized');
      }

      // Set canvas size to 16:9 aspect ratio
      canvas.width = 1280;
      canvas.height = 720;

      // Start capture loop
      setIsCapturing(true);
      startCaptureLoop();

      // Get canvas stream
      const canvasStream = canvas.captureStream(30); // 30 fps

      // Get microphone audio if available
      try {
        const audioStream = await navigator.mediaDevices.getUserMedia({ 
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          } 
        });
        audioStreamRef.current = audioStream;

        // Combine video from canvas and audio from microphone
        const combinedStream = new MediaStream();
        canvasStream.getVideoTracks().forEach(track => {
          combinedStream.addTrack(track);
        });
        audioStream.getAudioTracks().forEach(track => {
          combinedStream.addTrack(track);
        });

        // Create MediaRecorder with combined stream
        const mediaRecorder = new MediaRecorder(combinedStream, {
          mimeType: 'video/webm;codecs=vp9,opus',
          videoBitsPerSecond: 2500000, // 2.5 Mbps
        });

        mediaRecorderRef.current = mediaRecorder;
        recordedChunksRef.current = [];

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            recordedChunksRef.current.push(event.data);
          }
        };

        mediaRecorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          
          setRecordedSegments(prev => [...prev, {
            id: Date.now().toString(),
            url,
            blob,
            duration: recordingDuration,
            timestamp: new Date().toISOString(),
          }]);

          // Cleanup
          stopCaptureLoop();
          setIsCapturing(false);
          
          if (audioStreamRef.current) {
            audioStreamRef.current.getTracks().forEach(track => track.stop());
            audioStreamRef.current = null;
          }
        };

        mediaRecorder.start(1000); // Collect data every second
        setIsRecording(true);
        setIsPaused(false);
        
        // Start duration timer
        const startTime = Date.now();
        const timer = setInterval(() => {
          if (!mediaRecorderRef.current || mediaRecorderRef.current.state !== 'recording') {
            clearInterval(timer);
            return;
          }
          setRecordingDuration(Math.floor((Date.now() - startTime) / 1000));
        }, 1000);

      } catch (audioError) {
        console.warn('Could not get audio, recording video only:', audioError);
        
        // Record without audio
        const mediaRecorder = new MediaRecorder(canvasStream, {
          mimeType: 'video/webm;codecs=vp9',
          videoBitsPerSecond: 2500000,
        });

        mediaRecorderRef.current = mediaRecorder;
        recordedChunksRef.current = [];

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            recordedChunksRef.current.push(event.data);
          }
        };

        mediaRecorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          
          setRecordedSegments(prev => [...prev, {
            id: Date.now().toString(),
            url,
            blob,
            duration: recordingDuration,
            timestamp: new Date().toISOString(),
          }]);

          // Cleanup
          stopCaptureLoop();
          setIsCapturing(false);
        };

        mediaRecorder.start(1000);
        setIsRecording(true);
        setIsPaused(false);
        
        // Start duration timer
        const startTime = Date.now();
        const timer = setInterval(() => {
          if (!mediaRecorderRef.current || mediaRecorderRef.current.state !== 'recording') {
            clearInterval(timer);
            return;
          }
          setRecordingDuration(Math.floor((Date.now() - startTime) / 1000));
        }, 1000);
      }

    } catch (error) {
      console.error('Failed to start recording:', error);
      alert('Failed to start recording. Please try again.');
      setIsRecording(false);
      stopCaptureLoop();
      setIsCapturing(false);
    }
  }, [startCaptureLoop, stopCaptureLoop, recordingDuration]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
    }
  }, []);

  const pauseRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.pause();
      setIsPaused(true);
    }
  }, []);

  const resumeRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
      mediaRecorderRef.current.resume();
      setIsPaused(false);
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCaptureLoop();
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, [stopCaptureLoop]);

  return (
    <div className="bg-gray-800 rounded-lg p-4">
      <h3 className="text-sm font-semibold text-gray-300 mb-3">Canvas Recording</h3>
      
      {/* Hidden canvas for recording */}
      <canvas
        ref={canvasRef}
        id="recording-canvas"
        style={{ display: 'none' }}
        width={1280}
        height={720}
      />
      
      <div className="space-y-3">
        {!isRecording ? (
          <button
            onClick={startRecording}
            className="w-full px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <div className="w-2 h-2 bg-white rounded-full" />
            Start Recording Analysis
          </button>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span className="text-sm text-white">Recording: {recordingDuration}s</span>
              </div>
            </div>
            
            <div className="flex gap-2">
              {!isPaused ? (
                <button
                  onClick={pauseRecording}
                  className="flex-1 px-3 py-1 bg-yellow-600 hover:bg-yellow-700 text-white rounded transition-colors text-sm"
                >
                  Pause
                </button>
              ) : (
                <button
                  onClick={resumeRecording}
                  className="flex-1 px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded transition-colors text-sm"
                >
                  Resume
                </button>
              )}
              
              <button
                onClick={stopRecording}
                className="flex-1 px-3 py-1 bg-gray-600 hover:bg-gray-700 text-white rounded transition-colors text-sm"
              >
                Stop
              </button>
            </div>
          </div>
        )}
        
        {isCapturing && (
          <div className="text-xs text-green-400">
            ✓ Capturing video area with zoom and annotations
          </div>
        )}
        
        {/* Show recorded segments */}
        {recordedSegments.length > 0 && (
          <div className="space-y-2 mt-3 pt-3 border-t border-gray-700">
            <p className="text-xs text-gray-400">Recorded Segments:</p>
            {recordedSegments.map((segment, index) => (
              <div key={segment.id} className="flex items-center justify-between bg-gray-700 p-2 rounded">
                <span className="text-xs text-white">Recording {index + 1} ({segment.duration}s)</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = segment.url;
                      link.download = `analysis-${segment.id}.webm`;
                      link.click();
                    }}
                    className="text-xs px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                  >
                    Download
                  </button>
                  <button
                    onClick={() => {
                      URL.revokeObjectURL(segment.url);
                      setRecordedSegments(prev => prev.filter(s => s.id !== segment.id));
                    }}
                    className="text-xs px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CanvasRecorder;