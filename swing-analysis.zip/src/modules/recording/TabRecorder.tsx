import React, { useRef, useState, useCallback, useEffect } from 'react';

const TabRecorder: React.FC = () => {
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const displayStreamRef = useRef<MediaStream | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  
  const [isCapturing, setIsCapturing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordedSegments, setRecordedSegments] = useState<any[]>([]);

  // Lock scrolling and zoom during recording
  const lockPageInteraction = useCallback(() => {
    // Prevent scrolling
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    
    // Prevent zoom with wheel + ctrl/cmd
    const preventZoom = (e: WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    
    // Prevent keyboard zoom shortcuts
    const preventKeyZoom = (e: KeyboardEvent) => {
      // Prevent Cmd/Ctrl + Plus/Minus/0
      if ((e.ctrlKey || e.metaKey) && (e.key === '+' || e.key === '-' || e.key === '=' || e.key === '0')) {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    
    // Prevent pinch zoom on trackpad
    const preventGestureZoom = (e: Event) => {
      e.preventDefault();
    };
    
    document.addEventListener('wheel', preventZoom, { passive: false });
    document.addEventListener('keydown', preventKeyZoom, { passive: false });
    document.addEventListener('gesturestart', preventGestureZoom, { passive: false });
    document.addEventListener('gesturechange', preventGestureZoom, { passive: false });
    
    // Store cleanup functions
    return () => {
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
      document.removeEventListener('wheel', preventZoom);
      document.removeEventListener('keydown', preventKeyZoom);
      document.removeEventListener('gesturestart', preventGestureZoom);
      document.removeEventListener('gesturechange', preventGestureZoom);
    };
  }, []);

  const [cleanupLock, setCleanupLock] = useState<(() => void) | null>(null);

  const startRecording = useCallback(async () => {
    try {
      // Request tab capture (will show tab selector)
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: 'browser', // Prefer browser tab
        },
        audio: false, // We'll get audio separately
        preferCurrentTab: true, // Chrome 94+ hint to prefer current tab
      } as any);

      displayStreamRef.current = displayStream;
      console.log('Tab capture started');

      // Lock page interaction
      const cleanup = lockPageInteraction();
      setCleanupLock(() => cleanup);

      setIsCapturing(true);

      // Try to get microphone audio
      let combinedStream = displayStream;
      try {
        const audioStream = await navigator.mediaDevices.getUserMedia({ 
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          } 
        });
        audioStreamRef.current = audioStream;

        // Combine streams
        combinedStream = new MediaStream();
        displayStream.getVideoTracks().forEach(track => {
          combinedStream.addTrack(track);
        });
        audioStream.getAudioTracks().forEach(track => {
          combinedStream.addTrack(track);
        });
      } catch (audioError) {
        console.warn('Could not get audio, recording video only:', audioError);
      }

      // Create MediaRecorder with fallback codecs
      let mediaRecorder: MediaRecorder;
      const codecOptions = [
        { mimeType: 'video/webm;codecs=vp9,opus', videoBitsPerSecond: 2500000 },
        { mimeType: 'video/webm;codecs=vp8,opus', videoBitsPerSecond: 2500000 },
        { mimeType: 'video/webm', videoBitsPerSecond: 2500000 },
      ];
      
      let selectedCodec = null;
      for (const option of codecOptions) {
        if (MediaRecorder.isTypeSupported(option.mimeType)) {
          selectedCodec = option;
          console.log('Using codec:', option.mimeType);
          break;
        }
      }
      
      if (!selectedCodec) {
        throw new Error('No supported video codec found');
      }
      
      mediaRecorder = new MediaRecorder(combinedStream, selectedCodec);

      mediaRecorderRef.current = mediaRecorder;
      recordedChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        
        setRecordedSegments(prev => [...prev, {
          id: Date.now().toString(),
          url,
          blob,
          duration: recordingDuration,
          timestamp: new Date().toISOString(),
        }]);

        // Cleanup
        setIsCapturing(false);
        
        // Unlock page interaction
        if (cleanupLock) {
          cleanupLock();
          setCleanupLock(null);
        }
        
        if (displayStreamRef.current) {
          displayStreamRef.current.getTracks().forEach(track => track.stop());
          displayStreamRef.current = null;
        }
        
        if (audioStreamRef.current) {
          audioStreamRef.current.getTracks().forEach(track => track.stop());
          audioStreamRef.current = null;
        }
      };

      // Handle display stream ending (user stops sharing)
      displayStream.getVideoTracks()[0].addEventListener('ended', () => {
        stopRecording();
      });

      mediaRecorder.start(1000);
      setIsRecording(true);
      setIsPaused(false);
      
      // Start duration timer
      const startTime = Date.now();
      const timer = setInterval(() => {
        if (!mediaRecorderRef.current || mediaRecorderRef.current.state !== 'recording') {
          clearInterval(timer);
          return;
        }
        setRecordingDuration(Math.floor((Date.now() - startTime) / 1000));
      }, 1000);

    } catch (error: any) {
      console.error('Failed to start recording:', error);
      console.error('Error details:', error.message, error.stack);
      if (error.name === 'NotAllowedError') {
        alert('Screen recording permission denied. Please select the current tab when prompted.');
      } else {
        alert(`Failed to start recording: ${error.message || 'Unknown error'}`);
      }
      setIsRecording(false);
      setIsCapturing(false);
      
      // Unlock page interaction
      if (cleanupLock) {
        cleanupLock();
        setCleanupLock(null);
      }
      
      // Cleanup
      if (displayStreamRef.current) {
        displayStreamRef.current.getTracks().forEach(track => track.stop());
        displayStreamRef.current = null;
      }
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach(track => track.stop());
        audioStreamRef.current = null;
      }
    }
  }, [recordingDuration, lockPageInteraction, cleanupLock]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
    }
  }, []);

  const pauseRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.pause();
      setIsPaused(true);
    }
  }, []);

  const resumeRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
      mediaRecorderRef.current.resume();
      setIsPaused(false);
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      // Unlock page interaction if still locked
      if (cleanupLock) {
        cleanupLock();
      }
      
      if (displayStreamRef.current) {
        displayStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, [cleanupLock]);

  return (
    <div className="bg-gray-800 rounded-lg p-4">
      <h3 className="text-sm font-semibold text-gray-300 mb-3">Tab Recording</h3>
      
      
      <div className="space-y-3">
        {!isRecording ? (
          <button
            onClick={startRecording}
            className="w-full px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <div className="w-2 h-2 bg-white rounded-full" />
            Start Tab Recording
          </button>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span className="text-sm text-white">Recording: {recordingDuration}s</span>
              </div>
            </div>
            
            <div className="flex gap-2">
              {!isPaused ? (
                <button
                  onClick={pauseRecording}
                  className="flex-1 px-3 py-1 bg-yellow-600 hover:bg-yellow-700 text-white rounded transition-colors text-sm"
                >
                  Pause
                </button>
              ) : (
                <button
                  onClick={resumeRecording}
                  className="flex-1 px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded transition-colors text-sm"
                >
                  Resume
                </button>
              )}
              
              <button
                onClick={stopRecording}
                className="flex-1 px-3 py-1 bg-gray-600 hover:bg-gray-700 text-white rounded transition-colors text-sm"
              >
                Stop
              </button>
            </div>
          </div>
        )}
        
        {isCapturing && (
          <div className="space-y-1">
            <div className="text-xs text-green-400">
              ✓ Recording current tab
            </div>
            <div className="text-xs text-orange-400">
              🔒 Page scrolling and zoom locked during recording
            </div>
          </div>
        )}
        
        {/* Show recorded segments */}
        {recordedSegments.length > 0 && (
          <div className="space-y-2 mt-3 pt-3 border-t border-gray-700">
            <p className="text-xs text-gray-400">Recorded Segments:</p>
            {recordedSegments.map((segment, index) => (
              <div key={segment.id} className="flex items-center justify-between bg-gray-700 p-2 rounded">
                <span className="text-xs text-white">Recording {index + 1} ({segment.duration}s)</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = segment.url;
                      link.download = `analysis-${segment.id}.webm`;
                      link.click();
                    }}
                    className="text-xs px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                  >
                    Download
                  </button>
                  <button
                    onClick={() => {
                      URL.revokeObjectURL(segment.url);
                      setRecordedSegments(prev => prev.filter(s => s.id !== segment.id));
                    }}
                    className="text-xs px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TabRecorder;