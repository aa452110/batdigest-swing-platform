import React, { useRef, useState, useCallback } from 'react';

const SimpleRecorder: React.FC = () => {
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordedSegments, setRecordedSegments] = useState<any[]>([]);

  const startRecording = useCallback(async () => {
    try {
      // Get screen capture
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          width: 1280,
          height: 720,
        },
        audio: false,
      });

      // Try to get audio
      let combinedStream = displayStream;
      try {
        const audioStream = await navigator.mediaDevices.getUserMedia({ 
          audio: true,
        });
        
        // Combine video and audio
        combinedStream = new MediaStream();
        displayStream.getVideoTracks().forEach(track => {
          combinedStream.addTrack(track);
        });
        audioStream.getAudioTracks().forEach(track => {
          combinedStream.addTrack(track);
        });
      } catch (e) {
        console.log('No audio, recording video only');
      }

      // Create recorder
      const mediaRecorder = new MediaRecorder(combinedStream, {
        mimeType: 'video/webm',
      });

      mediaRecorderRef.current = mediaRecorder;
      recordedChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        
        setRecordedSegments(prev => [...prev, {
          id: Date.now().toString(),
          url,
          blob,
          duration: recordingDuration,
        }]);

        // Stop all tracks
        combinedStream.getTracks().forEach(track => track.stop());
      };

      // Start recording
      mediaRecorder.start(1000);
      setIsRecording(true);
      
      // Duration timer
      const startTime = Date.now();
      const timer = setInterval(() => {
        if (!mediaRecorderRef.current || mediaRecorderRef.current.state !== 'recording') {
          clearInterval(timer);
          return;
        }
        setRecordingDuration(Math.floor((Date.now() - startTime) / 1000));
      }, 1000);

    } catch (error) {
      console.error('Failed to start recording:', error);
      alert('Failed to start recording. Please try again.');
    }
  }, [recordingDuration]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setRecordingDuration(0);
    }
  }, []);

  return (
    <div className="bg-gray-800 rounded-lg p-4">
      <h3 className="text-sm font-semibold text-gray-300 mb-3">Screen Recording</h3>
      
      <div className="space-y-3">
        {!isRecording ? (
          <button
            onClick={startRecording}
            className="w-full px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <div className="w-2 h-2 bg-white rounded-full" />
            Start Recording
          </button>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span className="text-sm text-white">Recording: {recordingDuration}s</span>
              </div>
            </div>
            
            <button
              onClick={stopRecording}
              className="w-full px-3 py-1 bg-gray-600 hover:bg-gray-700 text-white rounded transition-colors text-sm"
            >
              Stop
            </button>
          </div>
        )}
        
        {/* Show recorded segments */}
        {recordedSegments.length > 0 && (
          <div className="space-y-2 mt-3 pt-3 border-t border-gray-700">
            <p className="text-xs text-gray-400">Recorded Segments:</p>
            {recordedSegments.map((segment, index) => (
              <div key={segment.id} className="flex items-center justify-between bg-gray-700 p-2 rounded">
                <span className="text-xs text-white">Recording {index + 1} ({segment.duration}s)</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = segment.url;
                      link.download = `analysis-${segment.id}.webm`;
                      link.click();
                    }}
                    className="text-xs px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                  >
                    Download
                  </button>
                  <button
                    onClick={() => {
                      URL.revokeObjectURL(segment.url);
                      setRecordedSegments(prev => prev.filter(s => s.id !== segment.id));
                    }}
                    className="text-xs px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SimpleRecorder;