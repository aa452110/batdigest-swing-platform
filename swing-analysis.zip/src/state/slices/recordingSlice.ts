import type { StateCreator } from 'zustand';
import type { AudioDevice, AudioRecording, RecordingState, AudioSettings } from '../../types/audio';

export interface RecordingSlice {
  // State
  recordings: AudioRecording[];
  currentRecording: AudioRecording | null;
  recordingState: RecordingState;
  audioSettings: AudioSettings;
  availableDevices: AudioDevice[];
  mediaRecorder: MediaRecorder | null;
  audioStream: MediaStream | null;

  // Actions
  setAvailableDevices: (devices: AudioDevice[]) => void;
  selectAudioDevice: (deviceId: string) => void;
  setAudioSettings: (settings: Partial<AudioSettings>) => void;
  startRecording: (videoTimestamp: number) => void;
  stopRecording: () => Promise<AudioRecording | null>;
  pauseRecording: () => void;
  resumeRecording: () => void;
  deleteRecording: (id: string) => void;
  clearAllRecordings: () => void;
  setAudioLevel: (level: number) => void;
  setMediaRecorder: (recorder: MediaRecorder | null) => void;
  setAudioStream: (stream: MediaStream | null) => void;
}

export const createRecordingSlice: StateCreator<RecordingSlice> = (set, get) => ({
  // Initial state
  recordings: [],
  currentRecording: null,
  recordingState: {
    isRecording: false,
    isPaused: false,
    startTime: null,
    duration: 0,
    audioLevel: {
      current: 0,
      peak: 0,
    },
  },
  audioSettings: {
    selectedDeviceId: null,
    isMuted: false,
    gain: 1,
    echoCancellation: true,
    noiseSuppression: true,
  },
  availableDevices: [],
  mediaRecorder: null,
  audioStream: null,

  // Actions
  setAvailableDevices: (devices) => {
    set({ availableDevices: devices });
  },

  selectAudioDevice: (deviceId) => {
    set((state) => ({
      audioSettings: { ...state.audioSettings, selectedDeviceId: deviceId },
    }));
  },

  setAudioSettings: (settings) => {
    set((state) => ({
      audioSettings: { ...state.audioSettings, ...settings },
    }));
  },

  startRecording: (videoTimestamp) => {
    set({
      recordingState: {
        isRecording: true,
        isPaused: false,
        startTime: videoTimestamp,
        duration: 0,
        audioLevel: { current: 0, peak: 0 },
      },
    });
  },

  stopRecording: async () => {
    const { mediaRecorder, recordingState } = get();
    
    if (!mediaRecorder || !recordingState.isRecording) {
      return null;
    }

    // Stop will trigger the dataavailable event
    return new Promise((resolve) => {
      const chunks: Blob[] = [];
      
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm;codecs=opus' });
        const url = URL.createObjectURL(blob);
        const recording: AudioRecording = {
          id: `rec-${Date.now()}`,
          blob,
          url,
          startTime: recordingState.startTime || 0,
          duration: recordingState.duration,
          createdAt: Date.now(),
        };

        set((state) => ({
          recordings: [...state.recordings, recording],
          currentRecording: recording,
          recordingState: {
            ...state.recordingState,
            isRecording: false,
            isPaused: false,
            startTime: null,
            duration: 0,
          },
        }));

        resolve(recording);
      };

      mediaRecorder.stop();
    });
  },

  pauseRecording: () => {
    const { mediaRecorder } = get();
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      mediaRecorder.pause();
      set((state) => ({
        recordingState: { ...state.recordingState, isPaused: true },
      }));
    }
  },

  resumeRecording: () => {
    const { mediaRecorder } = get();
    if (mediaRecorder && mediaRecorder.state === 'paused') {
      mediaRecorder.resume();
      set((state) => ({
        recordingState: { ...state.recordingState, isPaused: false },
      }));
    }
  },

  deleteRecording: (id) => {
    set((state) => {
      const recording = state.recordings.find((r) => r.id === id);
      if (recording) {
        URL.revokeObjectURL(recording.url);
      }
      return {
        recordings: state.recordings.filter((r) => r.id !== id),
        currentRecording: state.currentRecording?.id === id ? null : state.currentRecording,
      };
    });
  },

  clearAllRecordings: () => {
    const { recordings } = get();
    recordings.forEach((recording) => {
      URL.revokeObjectURL(recording.url);
    });
    set({
      recordings: [],
      currentRecording: null,
    });
  },

  setAudioLevel: (level) => {
    set((state) => ({
      recordingState: {
        ...state.recordingState,
        audioLevel: {
          current: level,
          peak: Math.max(level, state.recordingState.audioLevel.peak),
        },
      },
    }));
  },

  setMediaRecorder: (recorder) => {
    set({ mediaRecorder: recorder });
  },

  setAudioStream: (stream) => {
    const { audioStream } = get();
    // Clean up old stream
    if (audioStream && audioStream !== stream) {
      audioStream.getTracks().forEach((track) => track.stop());
    }
    set({ audioStream: stream });
  },
});