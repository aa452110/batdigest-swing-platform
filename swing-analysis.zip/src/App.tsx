import LoadVideoPage from './app/LoadVideoPage';

function App() {
  return <LoadVideoPage />;
}

export default App;
