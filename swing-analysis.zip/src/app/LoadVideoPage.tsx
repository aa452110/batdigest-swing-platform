import React, { useState } from 'react';
import VideoFileInput from '../modules/video/VideoFileInput';
import VideoPlayer from '../modules/video/VideoPlayer';
import VoiceRecorder from '../modules/audio/VoiceRecorder';
import AudioPlayback from '../modules/audio/AudioPlayback';
import { useVideoStore } from '../state/store';

const LoadVideoPage: React.FC = () => {
  const { videoFile } = useVideoStore();
  const [localFile, setLocalFile] = useState<File | null>(null);

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-white mb-8 text-center">Swing Analysis</h1>

        {!localFile && !videoFile ? (
          <div className="flex items-center justify-center mt-20">
            <div className="bg-gray-800 rounded-lg p-12 shadow-xl text-center">
              <svg
                className="mx-auto mb-6 text-gray-400"
                width="64"
                height="64"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 4v16M17 4v16M3 8h4m10 0h4M3 16h4m10 0h4"
                />
              </svg>
              <h2 className="text-xl font-semibold text-white mb-4">Load Video to Begin</h2>
              <p className="text-gray-400 mb-6">Select a video file to start your swing analysis</p>
              <VideoFileInput onFileSelect={setLocalFile} currentFile={localFile} />
            </div>
          </div>
        ) : (
          <div className="max-w-7xl mx-auto">
            <div className="mb-6 flex justify-center">
              <VideoFileInput onFileSelect={setLocalFile} currentFile={localFile} />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main video player - takes 2 columns on large screens */}
              <div className="lg:col-span-2">
                <VideoPlayer file={localFile || videoFile} className="w-full" />
              </div>
              
              {/* Audio controls sidebar - 1 column */}
              <div className="space-y-6">
                <VoiceRecorder />
                <AudioPlayback />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoadVideoPage;
