import React, { useState } from 'react';
import ComparisonVideoPlayer from '../modules/video/ComparisonVideoPlayer';
import CroppedRecorder from '../modules/recording/CroppedRecorder';
import ReferenceVideos from '../modules/video/ReferenceVideos';
import DrillVideos from '../modules/video/DrillVideos';

const LoadVideoPage: React.FC = () => {
  const [setVideo2, setSetVideo2] = useState<((file: File) => void) | null>(null);
  const [setVideo1, setSetVideo1] = useState<((file: File) => void) | null>(null);
  
  return (
    <div className="min-h-screen bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-white mb-8 text-center">Swing Analysis Comparison</h1>

        <div className="max-w-7xl mx-auto space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main video player with comparison - takes 2 columns on large screens */}
            <div className="lg:col-span-2">
              <ComparisonVideoPlayer 
                className="w-full"
                onVideo1Change={setSetVideo1}
                onVideo2Change={setSetVideo2}
              />
            </div>
            
            {/* Recording controls sidebar - 1 column */}
            <div className="space-y-6">
              <CroppedRecorder />
              <ReferenceVideos 
                onSelectVideo={(file) => {
                  if (setVideo2) {
                    setVideo2(file);
                  }
                }}
              />
              <DrillVideos 
                onSelectVideo={(file) => {
                  if (setVideo2) {
                    setVideo2(file);
                  }
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoadVideoPage;
